import net.stealthbot.*;

/**
 * This is the entry-point of StealthBot v3.
 * 
 * This class is responsible for setting up
 * an array of tier-ones, one for each bot
 * instance.
 * 
 * @author joe[x86]
 */
public class Main 
{

	/**
	 * Command line entry point
	 * @param args Command line arguments
	 */
	public static void main(String[] args)
	{
		System.out.println(" ____  _             _ _   _     ____        _           _____ ");
		System.out.println("/ ___|| |_ ___  __ _| | |_| |__ | __ )  ___ | |_  __   _|___ /"); 
		System.out.println("\\___ \\| __/ _ \\/ _` | | __| '_ \\|  _ \\ / _ \\| __| \\ \\ / / |_ \\ ");
		System.out.println(" ___) | ||  __/ (_| | | |_| | | | |_) | (_) | |_   \\ V / ___) |");
		System.out.println("|____/ \\__\\___|\\__,_|_|\\__|_| |_|____/ \\___/ \\__|   \\_/ |____/ ");

		System.out.println("\nDEBUGGING INFORMATION:");
		System.out.println("StealthBot v3 Prototype - Modified 10/4/09");
		System.out.println("OS: " + System.getProperty("os.name") + " (" +
			System.getProperty("os.arch") + ")");
		System.out.println("Java: " + System.getProperty("java.version") + " (" +
			System.getProperty("java.vendor") + ")");
		System.out.println("Please include this with all bug reports.\n");
		
		/* ****************************************************************
		 * 	/ ___|| |_ ___  __ _| | |_| |__ | __ )  ___ | |_  __   _|___ /
		 *	\___ \| __/ _ \/ _` | | __| '_ \|  _ \ / _ \| __| \ \ / / |_ \ 
		 *	 ___) | ||  __/ (_| | | |_| | | | |_) | (_) | |_   \ V / ___) |
		 *	|____/ \__\___|\__,_|_|\__|_| |_|____/ \___/ \__|   \_/ |____/ 
		 *	
		 *	DEBUGGING INFORMATION:
		 *  StealthBot v3 Prototype - Modified 10/4/09
		 *	OS: Linux (i386)
		 *	Java: 1.6.0_15 (Sun Microsystems Inc.)
		 *	Please include this with all bug reports.
		 * ****************************************************************/
		
		if(args.length == 0)
		{
			// This will catch all errors that eventually get passed all the
			// way up, just before giving them the opportunity to crash the JRE
			try
			{
				new BotManager();
			}
			catch(Exception ex)
			{
				System.err.println("Caught exception:" +
					"\nType: " + ex.getClass().getName() +
					"\nMessage: " + ex.toString() +
					"\nStack trace: ");
				ex.printStackTrace(System.out);
					
			}
		}
		else
		{
			
			// Create command
			if(args[0].equalsIgnoreCase("create"))
			{
				if(args.length >= 2)
				{
					System.out.println("Creating bot: " + args[1]);
					System.out.println("Bot creation " + (SBotManager.
						CreateBot(args[1]) ? "successful." : "failed."));
				}
				else
				{
					System.out.println("Arguments: create [name]");
				}
				return;
			}
			
			// Delete command
			if(args[0].equalsIgnoreCase("delete"))
			{
				if(args.length >= 2)
				{
					System.out.println("Deleting bot: " + args[1]);
					System.out.println("Bot deletion " + (SBotManager.
						DeleteBot(args[1]) ? "successful." : "failed."));
				}
				else
				{
					System.out.println("Arguments: delete [name]");
				}
				return;
			}
			
			System.out.println("Invalid command.");
			
		}
	}

}
