package net.stealthbot.exceptions;

/**
 * This can be used in a lot of situations. In tier zero, it's used when a
 * profile directory does not exist.
 * 
 * @author william
 */
public class DirectoryDoesNotExistException extends Exception
{
	private static final long serialVersionUID = 1L;
	
	private String information;
	
	public DirectoryDoesNotExistException(String error)
	{
		super();
		information = error;
	}
	
	public String toString()
	{
		return information;
	}
}
