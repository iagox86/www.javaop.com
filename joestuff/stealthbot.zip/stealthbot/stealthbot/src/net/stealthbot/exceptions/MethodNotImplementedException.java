package net.stealthbot.exceptions;

/**
 * This can be used for any kind of stub method.
 *
 * @author joe[x86]
 */
public class MethodNotImplementedException extends Exception
{
	private static final long serialVersionUID = 1L;
	
	private String information;
	
	public MethodNotImplementedException(String error)
	{
		super();
		information = error;
	}
	
	public String toString()
	{
		return information;
	}
}
