package net.stealthbot;

/**
 * This class takes care of the static tasks in bot management, such as
 * creating and destroying bots.
 * 
 * @author joe[x86]
 */
public class SBotManager
{
	
	/**
	 * Creates a new bot
	 * @param name Name of the new bot
	 * @return Success
	 */
	public static boolean CreateBot(String name)
	{
		return false;
	}
	
	/**
	 * Deletes a bot
	 * @param name Name of bot to delete
	 * @return Success
	 */
	public static boolean DeleteBot(String name)
	{
		return false;
	}

}
