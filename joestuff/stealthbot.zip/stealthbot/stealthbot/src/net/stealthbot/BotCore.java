package net.stealthbot;

import java.io.File;

/**
 * This is the core of a loaded bot. This class is tier one of the bot.
 * 
 * @author joe[x86]
 */
public class BotCore
{

	public BotCore(File profile)
	{
		System.out.println("Loading bot: " + profile.getAbsolutePath());
	}
}
