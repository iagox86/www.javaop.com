package net.stealthbot;

import java.io.File;
import java.util.Vector;

import net.stealthbot.exceptions.DirectoryDoesNotExistException;

/**
 * This class is entered from Main. It's responsible for maintaining a list of
 * all the running bots, and the functions such as creating and deleting them.
 * 
 * @author joe[x86]
 *
 */
public class BotManager
{
	private Vector<BotCore> botList;
	
	/**
	 * This constructor finds all bot profiles and loads them up.
	 */
	public BotManager() throws DirectoryDoesNotExistException
	{
		// Initialize class variables
		botList = new Vector<BotCore>();
		
		// Build and open the profile path
		String profilePath = System.getProperty("user.home")
		    + System.getProperty("file.separator") + ".stealthbot"
		    + System.getProperty("file.separator") + "profiles";
		File profileDirectory = new File(profilePath);
		
		if(!profileDirectory.isDirectory())
		{
			throw new DirectoryDoesNotExistException("Not a directory: "
				+ profileDirectory + "\nClosing bot.");
		}
		
		System.out.println("Loading profiles from " + profilePath);
		
		// Sort through the directory and profiles
		File[] fileList = profileDirectory.listFiles();
		for(int i = 0; i < fileList.length; i++)
		{
			// Regex match for *.ini
			if(fileList[i].isFile() && fileList[i].getName().matches(".*ini$"))
				botList.add(new BotCore(fileList[i]));
		}
	}

}
